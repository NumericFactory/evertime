-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: timers
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.14.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2015_12_28_130318_create_timers_table',1),('2016_01_02_113521_add_timer_settings',1),('2016_01_14_060258_add_custom_labels',1),('2016_01_17_100126_add_timer_type_column',1),('2016_01_18_075402_add_frenzy_column',1),('2016_01_18_141102_add_expired_image_column',1),('2016_01_18_151752_styles_field',1),('2016_01_20_140602_add_locale_column',1),('2016_01_22_083701_create_timer_deadlines_table',1),('2016_01_22_114913_add_upload_custom_image_column',1),('2016_01_23_072257_add_max_timers_column',2),('2016_01_25_131251_add_stripe_id',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('norio@maxiware.co.za','990a4bdd9774e4f24ecac6888b1b87e500386abc1043b04480dbaaa2ab7f54eb','2016-02-10 21:23:30');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timer_deadlines`
--

DROP TABLE IF EXISTS `timer_deadlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timer_deadlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timer_id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deadline` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `timer_deadlines_timer_id_index` (`timer_id`),
  KEY `timer_deadlines_email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timer_deadlines`
--

LOCK TABLES `timer_deadlines` WRITE;
/*!40000 ALTER TABLE `timer_deadlines` DISABLE KEYS */;
INSERT INTO `timer_deadlines` VALUES (1,26,'norio@maxiware.co.za','2016-02-10 16:11:34','2016-02-09 20:10:34','2016-02-09 20:10:34'),(2,26,'%email%','2016-02-10 16:11:48','2016-02-09 20:10:48','2016-02-09 20:10:48'),(3,28,'info@kalipseo.fr','2016-02-14 22:02:08','2016-02-09 22:59:08','2016-02-09 22:59:08'),(4,28,'enzo.b46@gmail.com','2016-02-14 22:02:49','2016-02-09 22:59:49','2016-02-09 22:59:49'),(5,34,'{!email}','2016-02-13 19:26:45','2016-02-10 21:23:45','2016-02-10 21:23:45'),(6,34,'franck@kalipseo.fr','2016-02-13 19:36:44','2016-02-10 21:33:44','2016-02-10 21:33:44'),(7,34,'info@kalipseo.fr','2016-02-13 19:40:35','2016-02-10 21:37:35','2016-02-10 21:37:35'),(8,35,'{!email}','2016-02-12 18:57:52','2016-02-10 21:55:52','2016-02-10 21:55:52'),(9,35,'franck@kalipseo.fr','2016-02-12 19:00:17','2016-02-10 21:58:17','2016-02-10 21:58:17'),(10,32,'info@kalipseo.fr','2016-02-14 23:45:22','2016-02-11 00:41:22','2016-02-11 00:41:22'),(11,34,'enzo.b46@gmail.com','2016-02-13 22:48:16','2016-02-11 00:45:16','2016-02-11 00:45:16'),(12,32,'enzo.b46@gmail.com','2016-02-15 13:40:48','2016-02-11 14:36:48','2016-02-11 14:36:48'),(13,33,'norio@maxiware.co.za','2016-02-13 00:03:33','2016-02-12 16:55:23','2016-02-12 16:55:23'),(14,33,'monica@maxiware.co.za','2016-02-16 16:09:59','2016-02-12 17:05:59','2016-02-12 17:05:59'),(15,33,'norio@maxiware.co.','2016-02-16 16:15:37','2016-02-12 17:11:37','2016-02-12 17:11:37'),(16,33,'norio@maxiware.co.z','2016-02-16 16:15:39','2016-02-12 17:11:39','2016-02-12 17:11:39'),(17,33,'undefined','2016-02-16 16:17:29','2016-02-12 17:13:29','2016-02-12 17:13:29'),(18,36,'undefined','2016-02-13 13:48:17','2016-02-12 17:47:17','2016-02-12 17:47:17'),(19,36,'norio@maxiware.co.za','2016-02-13 00:03:33','2016-02-12 17:47:42','2016-02-12 17:47:42'),(20,37,'{!email}','2016-02-16 21:24:44','2016-02-12 22:20:44','2016-02-12 22:20:44'),(21,37,'franck@kalipseo.fr','2016-02-16 21:26:47','2016-02-12 22:22:47','2016-02-12 22:22:47'),(22,37,'undefined','2016-02-16 21:27:20','2016-02-12 22:23:20','2016-02-12 22:23:20'),(23,33,'%email%','2016-02-21 16:48:30','2016-02-17 17:44:30','2016-02-17 17:44:30'),(24,33,'norio 2@maxiware.co.za','2016-02-21 16:48:58','2016-02-17 17:44:58','2016-02-17 17:44:58'),(25,33,'norio 4@maxiware.co.za','2016-02-21 16:58:22','2016-02-17 17:54:22','2016-02-17 17:54:22'),(26,33,'norio newguy@maxiware.co.za','2016-02-21 17:23:07','2016-02-17 18:19:07','2016-02-17 18:19:07'),(27,33,'norio newguy2@maxiware.co.za','2016-02-21 17:28:42','2016-02-17 18:24:42','2016-02-17 18:24:42'),(28,33,'norio newguy3@maxiware.co.za','2016-02-21 17:29:19','2016-02-17 18:25:19','2016-02-17 18:25:19');
/*!40000 ALTER TABLE `timer_deadlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timers`
--

DROP TABLE IF EXISTS `timers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timer_type` enum('evergreen','deadline') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'deadline',
  `offset_days` tinyint(4) NOT NULL,
  `offset_hours` tinyint(4) NOT NULL,
  `offset_minutes` tinyint(4) NOT NULL,
  `offset_seconds` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deadline` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expired_link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label_days` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label_hours` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label_minutes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `label_seconds` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `frenzy` text COLLATE utf8_unicode_ci NOT NULL,
  `upload_custom_image` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `expired_image` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `styles` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `timers_user_id_index` (`user_id`),
  KEY `timers_timer_type_index` (`timer_type`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timers`
--

LOCK TABLES `timers` WRITE;
/*!40000 ALTER TABLE `timers` DISABLE KEYS */;
INSERT INTO `timers` VALUES (2,2,'Test 26 Jan','deadline',7,7,7,15,'2016-01-27 12:07:32','2016-01-27 17:07:32','2016-01-27 13:22:00','Europe/Paris','http://franckrocca.com','http://google.com','days','hours','minutes','seconds','[{\"offset_value\":\"2\",\"offset_field\":\"minutes\",\"redirect_link\":\"http:\\/\\/kalipseo.fr\",\"warning_message\":\"bonus perdu\"}]','0','expired-1.gif','default'),(3,2,'test spanish','deadline',0,0,0,0,'2016-01-27 00:25:13','2016-01-27 05:25:13','2016-01-27 01:27:00','Europe/Paris','http://franckrocca.com','http://google.com','dias','oras','minutos','secundos','[]','0','expired-1.gif','{\"background\":\"#5922cf\",\"foreground\":\"#ffffff\",\"font\":\"Orbitron Regular\",\"format\":\"dhms\"}'),(4,2,'test frenzy','deadline',0,0,0,0,'2016-02-07 02:10:18','2016-02-07 07:10:18','2016-02-11 14:00:00','Europe/Paris','http://franckrocca.com','http://google.com','days','hours','minutes','seconds','[]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Oswald Bold\",\"format\":\"dhms\"}'),(5,2,'Promo de la saint-valentin','evergreen',2,1,4,13,'2016-02-01 23:40:14','2016-02-02 04:40:14','2016-02-13 16:10:00','Europe/Paris','http://www.goo.com','http://www.goo.com','days','hours','minutes','seconds','[{\"offset_value\":\"3\",\"offset_field\":\"days\",\"redirect_link\":\"http:\\/\\/kalipseo.fr\",\"warning_message\":\"Bouge tes fesses\"}]','1','2_56afecde69682.jpg','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(6,2,'offre webi 28jan','deadline',0,0,0,0,'2016-02-02 11:53:27','2016-02-02 16:53:27','2016-02-07 23:59:00','Europe/Paris','http://go.franckrocca.com/mfbm-university-emeric','https://lp.franckrocca.com/mfbm-university-offre-launch-termineeZXtIYgFW','jours','heures','minutes','secondes','[{\"offset_value\":\"6\",\"offset_field\":\"days\",\"redirect_link\":\"http:\\/\\/go.franckrocca.com\\/mfbm-university-emeric\",\"warning_message\":\"Le temps s\'\\u00e9coule vite\"}]','0','expired-3.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Regular\",\"format\":\"dhms\"}'),(12,2,'offre webi 28 jan 2','deadline',0,0,0,0,'2016-02-05 03:03:23','2016-02-05 08:03:23','2016-02-07 23:59:00','Europe/Paris','http://go.franckrocca.com/mfbm-university-emeric','https://lp.franckrocca.com/mfbm-university-offre-launch-termineeZXtIYgFW','jours','heures','minutes','secondes','[{\"offset_value\":\"6\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Le temps s\'\\u00e9coule vite\"}]','0','expired-3.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Regular\",\"format\":\"dhms\"}'),(13,2,'T&C Launch','deadline',0,0,0,0,'2016-02-24 13:43:50','2016-02-24 18:43:50','2016-02-28 23:59:00','America/Los_Angeles','https://evertimer.io/tc-special-offer-launch','https://evertimer.io/welcomecof1ujqx','days','hours','minutes','seconds','[{\"offset_value\":\"7\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Start Driving More Sales Now\"}]','0','expired-6.gif','{\"background\":\"#292c44\",\"foreground\":\"#ffffff\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(14,2,'try','deadline',0,0,0,0,'2016-02-06 21:17:25','2016-02-06 21:17:25','2016-02-13 16:15:00','America/Los_Angeles','https://evertimer.io','https://evertimer.io/lp','days','hours','minutes','seconds','[]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(15,2,'T&C Launch 2','deadline',0,0,0,0,'2016-02-08 15:50:06','2016-02-08 20:50:06','2016-02-12 23:59:00','America/Los_Angeles','https://evertimer.io/tc-special-offer-launch','https://evertimer.io/too-late','days','hours','minutes','seconds','[{\"offset_value\":\"7\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"12 Hours Left to GET All Bonuses\"}]','0','expired-1.gif','{\"background\":\"#000000\",\"foreground\":\"#ffffff\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(16,2,'Test UNI','deadline',7,0,0,0,'2016-02-08 19:52:21','2016-02-09 00:52:21','2016-02-15 20:30:00','Europe/Paris','http://evertimer.io','http://evertimer.io/lp','jours','heures','minutes','secondes','[{\"offset_value\":\"7\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Loic tu as ta r\\u00e9ponse\"},{\"offset_value\":\"5\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"BONUS 1 Perdu\"},{\"offset_value\":\"4\",\"offset_field\":\"hours\",\"redirect_link\":\"\",\"warning_message\":\"PLus que 4H avant augmentation du prix\"}]','0','expired-6.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(28,2,'Franck','evergreen',5,4,3,4,'2016-02-09 23:15:12','2016-02-10 04:15:12','2016-02-16 14:24:00','EST','https://evertimer.io/evergreen-test','https://evertimer.io/lp','jours','hours','minutes','seconds','[{\"offset_value\":\"6\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"helo\"},{\"offset_value\":\"3\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Hurry Already One Bonus LOST\"},{\"offset_value\":\"4\",\"offset_field\":\"hours\",\"redirect_link\":\"\",\"warning_message\":\"It\'s gone in hours\"}]','0','expired-1.gif','{\"background\":\"#a32323\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(29,2,'Test','deadline',0,0,0,0,'2016-02-09 14:35:41','2016-02-09 19:35:41','2016-02-16 14:24:00','America/Los_Angeles','https://evertimer.io','https://evertimer.io/lp','days','hours','minutes','seconds','[{\"offset_value\":\"9\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Il \\u00e9tait une fois un petit lapin qui sortai\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(30,2,'fermeture cedric','deadline',0,0,0,0,'2016-02-10 07:50:14','2016-02-10 12:50:14','2016-02-10 23:59:00','Europe/Paris','http://mfbm46.cedrican.hop.clickbank.net/','http://mfbm46.cedrican.hop.clickbank.net/','jours','heures','minutes','secondes','[{\"offset_value\":\"2\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Vivez Vos R\\u00eaves d\\u00e8s Maintenant\"},{\"offset_value\":\"4\",\"offset_field\":\"hours\",\"redirect_link\":\"\",\"warning_message\":\"Dans 4H il sera trop tard !\"}]','0','expired-4.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(31,2,'test evergreen new','evergreen',4,4,4,4,'2016-02-10 14:53:50','2016-02-10 19:53:50','2016-02-17 14:53:00','EST','https://evertimer.io','https://evertimer.io/lp','days','hours','minutes','seconds','[{\"offset_value\":\"5\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"tes\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(32,2,'test EG new','evergreen',4,4,4,4,'2016-02-10 20:08:22','2016-02-10 20:08:22','2016-02-17 15:07:00','EST','https://app.evertimer.io','https://app.evertimer.io/lp','days','hours','minutes','seconds','[{\"offset_value\":\"5\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"test ew\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#e00000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(33,1,'EV Test','evergreen',4,4,4,4,'2016-02-17 13:19:42','2016-02-17 18:19:42','2016-02-17 15:31:00','EST','http://techassassin.co/timer-test/','http://techassassin.co/timer-test/','days','hours','minutes','seconds','[]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#c21c1c\",\"font\":\"Orbitron Regular\",\"format\":\"dhms\"}'),(34,2,'test EG new 2','evergreen',3,3,3,3,'2016-02-10 20:53:37','2016-02-10 20:53:37','2016-02-17 15:52:00','EST','https://evertimer.io/ev-test','https://app.evertimer.io/lp','days','hours','minutes','seconds','[{\"offset_value\":\"1\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"test new\"}]','0','expired-6.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Bold\",\"format\":\"dhms\"}'),(35,2,'test eg 3','evergreen',2,2,2,2,'2016-02-10 21:55:03','2016-02-10 21:55:03','2016-02-17 16:54:00','EST','https://evertimer.io/ev-test','https://evertimer.io/ev-test-','days','hours','minutes','seconds','[{\"offset_value\":\"1\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"works or not !\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Regular\",\"format\":\"dhms\"}'),(36,1,'EV New','evergreen',1,1,1,1,'2016-02-17 11:08:52','2016-02-17 16:08:52','2016-02-19 12:20:00','EST','https://app.evertimer.io/timer/create','https://app.evertimer.io/timer/','days','hours','minutes','seconds','[]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#9e0909\",\"font\":\"Lato Regular\",\"format\":\"dhms\"}'),(37,2,'Test cross device','evergreen',4,4,4,4,'2016-02-12 17:19:01','2016-02-12 22:19:01','2016-02-19 17:17:00','EST','https://evertimer.io/ev-test','https://evertimer.io/','days','hours','minutes','seconds','[{\"offset_value\":\"1\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"is it working ?\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Thin\",\"format\":\"dhms\"}'),(38,2,'test upload image','deadline',0,0,0,0,'2016-02-16 11:17:19','2016-02-16 16:17:19','2016-02-16 11:10:00','Europe/Paris','https://app.evertimer.io','https://app.evertimer.io/lp','days','hours','minutes','seconds','[]','0','expired-6.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Regular\",\"format\":\"dhms\"}'),(39,2,'test 2 expired','deadline',0,0,0,0,'2016-02-16 11:18:28','2016-02-16 16:18:28','2016-02-16 11:16:00','Europe/Paris','https://app.evertimer.io/','https://app.evertimer.io/lp','days','hours','minutes','seconds','[]','0','expired-6.gif','default'),(40,1,'Test','deadline',0,0,0,0,'2016-02-17 16:15:03','2016-02-17 16:15:03','2016-02-24 11:14:00','Europe/Paris','https://app.evertimer.io/timer/create','https://app.evertimer.io/timer/create2','days','hours','minutes','seconds','[{\"offset_value\":\"1\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"test\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#cf2f2f\",\"font\":\"Orbitron Regular\",\"format\":\"dhms\"}'),(41,2,'Test','evergreen',4,12,7,18,'2016-02-19 15:23:30','2016-02-19 15:23:30','2016-02-26 10:21:00','America/New_York','https://app.evertimer.io','https://app.evertimer.io/lp','jours','hours','minutes','seconds','[{\"offset_value\":\"5\",\"offset_field\":\"days\",\"redirect_link\":\"\",\"warning_message\":\"Bouge ton cul\"}]','0','expired-1.gif','{\"background\":\"#ffffff\",\"foreground\":\"#ff0000\",\"font\":\"Lato Regular\",\"format\":\"dhms\"}');
/*!40000 ALTER TABLE `timers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `max_timers_count` int(10) unsigned NOT NULL DEFAULT '3',
  `max_frenzy_count` int(10) unsigned NOT NULL DEFAULT '3',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stripe_customer_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Norio2','norio@maxiware.co.za','$2y$10$RQ5.bU76YWNRWeC9XaaK2utlLBbuLNQtOVn2hQ6bwowFLsKAZu9Mu','PLY2gVtJBN5BOYdvaAQTFO2CPFpX489pq8KxeB8tW11gAzcw3AIkV51GBcpc','en',999,999,'2016-02-23 14:00:45','2016-02-23 18:55:21',''),(2,'Franck','f.rocca@kalipseo.fr','$2y$10$6cYafeQSDcwqM2yCa.TL7OLL8Vuhwv0PfOTtCc68DVgBMIJcY33/m','r4Kyds4Gtplmin1rP31seuOIRAah7yBzbjBRPJggmpIeSBPPo5kuFb3rcR55','en',999,999,'2016-02-20 16:49:58','2016-02-20 21:49:58',''),(8,'Norio PFS','norio@puppiesforsale.co.za','$2y$10$yfvrLTA24dETRfl5CYS2AegyXRHk3aX09M34RFP7Ke1Fdw25zUK42',NULL,'en',9999,9999,'2016-02-10 10:39:54','2016-02-10 15:39:54','cus_7sOerGr7HQ8XYE'),(9,'test','enzo.b46+test@gmail.com','$2y$10$zwGp/jOWXPqsRjqE/pJpy.40D/HI16TZjUOgp46VezU3a6RpU/6UW',NULL,'en',9999,9999,'2016-02-10 15:07:34','2016-02-10 15:07:34','cus_7sNTrYlgQ4GSRB'),(10,'test','info@kalipseo.fr','$2y$10$IdsDaZ9eIikyp/OJ7eoRQORR0teL0/8IRGbkKWj6ZF4qriUUQdnua',NULL,'en',9999,9999,'2016-02-10 15:55:30','2016-02-10 15:55:30','cus_7sPBtqvueU7NOp'),(14,'test','enzo.b46+testnew1@gmail.com','$2y$10$.4MOB5tQxOIvqUVd/VlmLOvGM9KRAxXg4hPg7HIDNOvMeFEbmmxIy',NULL,'en',9999,9999,'2016-02-10 19:45:33','2016-02-10 19:45:33','cus_7skiInkf7uevCD'),(15,'norio@techassassin.co','norio@techassassin.co','$2y$10$/.cSTa9iq7YfYq59mgMoD.9dAPJoQBUMkEOL6rGeKgb4dtQanH.w.',NULL,'en',9999,9999,'2016-02-10 20:02:45','2016-02-10 20:02:45','cus_7skzSQOSWnjIJ5'),(17,'franck@franckrocca.com','franck@franckrocca.com','$2y$10$2Xv9..yxlAhdKFYHxL7zIeyWVpijuDZ.3faxLVkXZAGyiishZNmju','LU87kEvg3z9nIzCJbS7RLlkj4HXGh2vf1zNZ6lTO2MWCD9p0J4gCr03vdTKx','en',0,0,'2016-02-19 11:17:56','2016-02-19 16:17:56','cus_7slbxeAlBllCga'),(19,'kalipseo.webmarketing@gmail.com','kalipseo.webmarketing@gmail.com','$2y$10$nhWCfTJmhqqtDV5QSpJpYO1Jj19drtgtjZoJsgRb3Awcox2LlJZ/O',NULL,'en',0,0,'2016-02-10 17:44:24','2016-02-10 22:44:24','cus_7smFSjYDoG2Veu'),(20,'Norio Gmail','norio.desousa@gmail.com','$2y$10$euzaRBaONDdhnNBUoPHHZeuA32xiu.hPVtBLK57nyWr1qXk9YhXXe',NULL,'en',9999,9999,'2016-02-10 21:42:47','2016-02-10 21:42:47','cus_7smcLGfMR1U5W0'),(21,'sandie@kalipseo.fr','sandie@kalipseo.fr','$2y$10$6d9HukCpn3RAeACh2abjSOYziAtPjWdOk0CXi4Sxjsx3bLN0z5Uom',NULL,'en',0,0,'2016-02-10 17:43:50','2016-02-10 22:43:50','cus_7smhx171f1k8Qb'),(24,'compta@kalipseo.fr','compta@kalipseo.fr','$2y$10$vbqegbTb1ixHnUuW2Oca.et0Lqd5D6soblCWW71e8D44Pu1oruLSG',NULL,'en',0,0,'2016-02-17 15:11:03','2016-02-17 20:11:03','cus_7snddz4jtHjQrE');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-25  4:58:18
